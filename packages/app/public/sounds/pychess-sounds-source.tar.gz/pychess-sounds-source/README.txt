The PyChess piece sounds in HunChess, and their source (GNU GPL version 3)

HunChess (https://hunchess.com) plays these sounds from PyChess (https://github.com/pychess/pychess), by the PyChess
authors, under the GNU General Public License, version 3. They're separate files the game plays, not part of its code:

- /sounds/move.mp3, /sounds/capture.mp3 and /sounds/castle.mp3: PyChess's mov2.wav, capture2.wav and castle.wav,
  converted to mp3.
- /sounds/pieces/move-classic-light.mp3, -deep.mp3, -soft.mp3 and capture-classic-light.mp3, -deep.mp3, -soft.mp3:
  variations made from mov2.wav and capture2.wav by scripts/piece-sounds.py (modified by HunChess on October 12,
  2026: a small pitch shift, a gentle EQ, a slightly shorter or longer decay, and leveled to the classic's loudness;
  the parameters are VARIATIONS in the script).

This archive is their complete corresponding source:

- pychess/: the original WAV files, unchanged, from PyChess commit 94771355c49a04c3e8fc16dd135fe8ceed78a277 (its sounds/ folder).
    mov2.wav  sha256 384da365ee83f8634ade0dbde2cca630d1445a0c88c66f25482336ad215664b6
    capture2.wav  sha256 940fa6da94c79988333a8b50ce64feada662846b02b9a0e82109013bbdd29dc0
    castle.wav  sha256 af72c88f87141a4a82e876bfb9c3a60628b8f528c7f85bd3638bf948e0964bcc
- scripts/piece-sounds.py: the script that made the variations, under the GPL-3.0 like the sounds it makes.
- packages/app/public/sounds/move.mp3, capture.mp3, castle.mp3: the classic sounds as the game serves them (the
  script levels each variation to the loudness of move.mp3 or capture.mp3).
- COPYING.txt: the GNU General Public License, version 3.

To make the variations again (Python 3 with numpy, and ffmpeg), from this folder:

    python3 scripts/piece-sounds.py pychess move-classic-light move-classic-deep move-classic-soft capture-classic-light capture-classic-deep capture-classic-soft

They're written to packages/app/public/sounds/pieces/.
